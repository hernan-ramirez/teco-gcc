# GCC - Aplicación de gestión de comunicaciones de contratistas

Esta aplicación consta de tres listas vinculadas.
Las listas principales son los 'Eventos' y las 'Comunicaciones'.
Un evento contiene varias comunicaciones y son filtradas por su seleccion.
Al seleccionar una comunicación se muestra un panel de propiedades y acciones.

> Nota. Esta aplicación es del tipo de página completa, por lo que luego de instalar es necesario crear una página en el sitio desde la solapa 'Apliaciones'.



## Solución

La solución instala las tres listas necesarias y los scripts para ejecutarse en un ámbito local de la colección.
Para instalarla es necesario contar con un sitio y un App Catalog de la colección.
Los pasos son:

* Crar sitio (del tipo comunicaciones si es posible, en blanco)
* Agregar App Catalog
* Instalar las listas desde el template
* Instalar la solución SPFX 

Para ello correr las siguientes líneas desde Powershell luego de crear el sitio:

> Nota: Reemplazar el tenant y sitio destino

```bash
$tenant = "mi-tenant"
$sitio = "mi-sitio"
$cred = Get-Credential

$adminConn = Connect-SPOService -Url "https://" + $tenant + "-admin.sharepoint.com" -Credential $cred

$site = Get-SPOSite "https://" + $tenant + ".sharepoint.com/sites/" + $sitio

# Agrega el AppCatalog a la colección
Add-SPOSiteCollectionAppCatalog -Site $site
```

Luego para instalar las listas correr la siguiente linea

```bash
$siteConn = Connect-PnPOnline –Url ("https://" + $tenant + ".sharepoint.com/sites/" + $sitio) –Credentials $cred

# Instala las listas necesarias con contenido de ejemplo
Apply-PnPProvisioningTemplate -Path ".\provisioning\gcc-lists.xml" -Handlers Lists -Verbose -Connection $siteConn
```

Por último para instalar el paquete SPFX ejecutar

```bash
# Agrega y publica el SPFX
Add-PnPApp -Path ".\sharepoint\solution\gcc-app.sppkp" -Publish -Connection $siteConn
```
Luego de esto, ir al sitio y crear una página.
En las plantillas de páginas aparecerá una solapa de `Aplicaciones` donde se verá la app de GCC


## Building the code

```bash
git clone the repo
npm i
npm i -g gulp
gulp
```

El bundle del paquete produce lo siguiente:

* lib/* - intermediate-stage commonjs build artifacts
* dist/* - the bundled script, along with other resources


### Build options

* gulp clean 
* gulp serve


### Deploy

* gulp clean
* gulp bundle --ship
* gulp package-solution --ship
* Subir .sppkg file desde `sharepoint\solution` al App Catalog de la colección
	* Ejemplo: https://`<tenant>`.sharepoint.com/sites/`<site>`/AppCatalog
* Agregar la web part al site collection (opcional)
* Agregar una página del tipo "Aplicación"


