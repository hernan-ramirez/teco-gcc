/* tslint:disable */
require("./Eventos.module.css");
const styles = {
  eventos: 'eventos_22355324',
  cabecera: 'cabecera_22355324',
  error: 'error_22355324',
  msg: 'msg_22355324',
  info: 'info_22355324',
};

export default styles;
/* tslint:enable */