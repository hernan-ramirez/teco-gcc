/* tslint:disable */
require("./ComunicacionesDeContratistas.module.css");
const styles = {
  comunicacionesDeContratistas: 'comunicacionesDeContratistas_1c3c79b4',
  container: 'container_1c3c79b4',
  row: 'row_1c3c79b4',
  column: 'column_1c3c79b4',
  'ms-Grid': 'ms-Grid_1c3c79b4',
  title: 'title_1c3c79b4',
  subTitle: 'subTitle_1c3c79b4',
  description: 'description_1c3c79b4',
  eventos: 'eventos_1c3c79b4',
  comunicaciones: 'comunicaciones_1c3c79b4',
};

export default styles;
/* tslint:enable */