/* tslint:disable */
require("./Panel.module.css");
const styles = {
  panel: 'panel_fc58c200',
  tituloCom: 'tituloCom_fc58c200',
  cuerpoCom: 'cuerpoCom_fc58c200',
};

export default styles;
/* tslint:enable */