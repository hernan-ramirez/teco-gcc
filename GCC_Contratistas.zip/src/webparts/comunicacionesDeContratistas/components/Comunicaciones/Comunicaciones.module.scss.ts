/* tslint:disable */
require("./Comunicaciones.module.css");
const styles = {
  comunicaciones: 'comunicaciones_b106dbfa',
  cabecera: 'cabecera_b106dbfa',
  titulo: 'titulo_b106dbfa',
  tipo: 'tipo_b106dbfa',
  fecha: 'fecha_b106dbfa',
  cuerpo: 'cuerpo_b106dbfa',
  error: 'error_b106dbfa',
  msg: 'msg_b106dbfa',
  info: 'info_b106dbfa',
};

export default styles;
/* tslint:enable */