declare interface IComunicacionesDeContratistasWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ComunicacionesDeContratistasWebPartStrings' {
  const strings: IComunicacionesDeContratistasWebPartStrings;
  export = strings;
}
