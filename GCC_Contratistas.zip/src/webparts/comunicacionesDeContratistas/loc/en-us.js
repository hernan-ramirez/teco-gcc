define([], function () {
  return {
    "PropertyPaneDescription": `
Esta es esclusiva de GCC (Gestión de Comunicaciones de Contratistas).
Consta de dos listas realcionadas.
Los módulos principales son los eventos y las comunicaciones.
Un evento contiene varias comunicaciones y son filtradas por su selección.
Al seleccionar una comunicación se muestra un panel de propiedades y acciones.
    `,
    "BasicGroupName": "Propiedades generales",
    "DescriptionFieldLabel": "Descripción adicional de la Aplicación"
  }
});